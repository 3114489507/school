- >1. 求极限
  $$\lim_{n\to\infty}\sum_{k=1}^n\frac1{\sqrt{n^2+k}}$$
  2. 求极限
  $$\lim_{n\to\infty}\sum_{k=1}^n\frac{\sqrt{(n+k)(n+k+1)}}{n^2}$$
-
- 如果我们要证明 $$\sum_{n=1}\limits^\infty a_n<+\infty$$，相当于证明 $$L+o(1)=\sum\limits_{n=1}^\infty a_n=\sum\limits_{k=1}^\infty f(n)+o(\frac1n)$$，两边同时取极限便有级数极限为 $$L$$。
- 这表明只要将每一项拆成易求和的项和 $$o(\frac1n)$$ 阶小量，就能得到极限结果，允许我们不用对过多的余项进行讨论。
- ## Sol 1 & 2
- $$\frac1{\sqrt{n^2+k}}=\frac{1}{n\sqrt{1+\frac k{n^2}}}=\frac 1n\left(1+o(1)\right)$$
  从而
  $$\sum_{k=1}^n\frac 1{\sqrt{n^2+k}}=\sum_{k=1}^n\frac 1n+o(\frac 1n)=1+o(1)$$
	- $$\frac{\sqrt{(n+k)(n+k+1)}}{n^2}=\frac{n+k}{n^2}\sqrt{1+\frac 1{n+k}}=\frac{n+k}{n^2}\left(1+o(1)\right)$$
	  从而
	  $$\sum_{k=1}^n\frac{\sqrt{(n+k)(n+k+1)}}{n^2}=\sum_{k=1}^n\frac{n+k}{n^2}\left(1+o(1)\right)=\left(1+\frac{n+1}{2n}\right)\left(1+o(1)\right)$$
- > 3. 求极限
  $$\lim_{n\to\infty}\sum_{k=1}^n\frac{\sqrt{k(k+1)}}{n^2+k}$$
- ## Sol 3
- $$\frac{\sqrt{k(k+1)}}{n^2+k}=\frac k{n^2}\left(1+o(1)\right)\left(1+o(\frac 1n)\right)=\frac k{n^2}\left(1+o(1)\right)$$
  从而
  $$\sum_{k=1}^n\frac{\sqrt{k(k+1)}}{n^2+k}=\sum_{k=1}^n\frac k{n^2}\left(1+o(1)\right)=\frac{n+1}{2n}\left(1+o(1)\right)$$
  进而
  $$\lim_{n\to\infty}\sum_{k=1}^n\frac{\sqrt{k(k+1)}}{n^2+k}=\frac 12$$
- > 4. 求极限
  $$\lim_{n\to\infty}\sum_{k=1}^n\frac{q^\frac kn}{n-\frac 1k}$$
- $$\sum=\sum_{k=1}^n\frac {q^{\frac kn}}n\frac 1{1-\frac{1}{nk}}\\=\sum_{k=1}^n\frac {q^{\frac kn}}n\left(1+O\left(\frac 1n\right)\right)\\=q^{\frac 1n}\frac {q-1}{n(q^{\frac 1n}-1)}\left(1+O\left(\frac 1n\right)\right)$$
- ~~使用 mathdf~~我们有
  $$\lim_{n\to\infty}\sum=\frac {q-1}{\ln q}$$
- >5. 求极限
  $$\lim_{n\to\infty}\left(\sum_{k=1}^n\frac 1{\sqrt{n^2+k}}\right)^n$$
- 注意到
  $$\left(1+x\right)^n=1+nx+\frac{n(n-1)}2x^2+\dots$$
  取 $$x=O\left(\frac 1{n^{2}}\right)$$ 时
  $$\left(1+x\right)^n=1+nO\left(\frac 1{n^2}\right)+\frac{n(n-1)}2O\left(\frac 1{n^4}\right)+\dots=1+O(\frac 1n)$$
- 从而只需对 $$\sum$$ 做精度为 $$o\left(\frac 1{n^2}\right)$$ 的估计。
- $$\sum_{k=1}^n\frac 1{\sqrt{n^2+k}}=\sum_{k=1}^n\frac 1n\frac 1{\sqrt{1+\frac k{n^2}}}\\=\sum_{k=1}^n\frac 1n\left(1-\frac 12\frac k{n^2}+O\left(\frac 1{n^2}\right)\right)\\=1-\frac{n+1}{4n^2}+O\left(\frac 1{n^2}\right)\\=1-\frac 1{4n}+O\left(\frac 1{n^2}\right)$$
- 进而
  $$\left(\sum\right)^n=\left(1-\frac 1{4n}\right)^n\left(1+O\left(\frac 1{n^2}\right)\right)^n=\left(1-\frac 1{4n}\right)^n\left(1+O\left(\frac 1n\right)\right)$$
- 于是
  $$\lim_{n\to\infty}\left(\sum\right)^n=e^{-\frac 14}$$
- >6. 求极限
  $$\lim_{n\to\infty}\frac 1n\sqrt[n]{n(n+1)(n+2)\dots(2n+1)}$$
- $$S_n=n^{\frac 2n}\sqrt[n]{\prod_{k=1}^{n+1}\left(1+\frac kn\right)}\\=n^{\frac 2n}\exp\left(\frac 1n\sum_{k=1}^{n+1}\ln\left(1+\frac kn\right)\right)$$
- 其中
  $$\lim_{n\to\infty}n^{\frac 2n}=1$$
  $$\lim_{n\to\infty}\frac 1n\sum_{k=1}^{n+1}\ln\left(1+\frac kn\right)=\int_0^1\ln(1+x)dx=2\ln2-1$$
- 从而
  $$\lim=\exp(2\ln2-1)=\frac 4e$$
- >7. 求极限
  $$\lim_{n\to\infty}\prod_{k=1}^n\left(1-\frac k{n^2}\right)$$
- $$S_n=\exp\left(\sum_{k=1}^n\ln\left(1-\frac k{n^2}\right)\right)\\=\exp\left(\sum_{k=1}^n-\frac k{n^2}+O\left(\frac 1{n^2}\right)\right)\\=\exp\left(-\frac {n+1}{2n}+O\left(\frac 1n\right)\right)\\=\exp\left(-\frac 12+O\left(\frac 1n\right)\right)$$
- 从而
  $$S_n\to \frac 1{\sqrt e}$$
- >8. 求极限
  $$\lim_{n\to\infty}\frac{1+\sum\limits_{k=2}^n\sqrt[k]{k+2^k}}n$$
- $$S_n=\frac 1n+\sum_{k=2}^n\frac 2n\sqrt[k]{1+\frac k{2^k}}\\=\frac 1n+\sum_{k=2}^n\frac 2n\left(1+O\left(\frac 1{2^k}\right)\right)\\=2-\frac 1n+\frac 2nO(1)$$
- 从而 $$S_n\to2$$
- >9.求极限
  $$\lim_{n\to\infty}\sum_{k=1}^n\frac{H_{k+1}}{k(k+1)}$$
- $$S_n=1-\frac 1{n+1}+\sum_{j=2}^{n+1}\frac 1j\sum_{k=j-1}^n\frac 1{k(k+1)}\\=1+o(1)+\sum_{j=2}^{n+1}\frac 1j\left(\frac1{j-1}-\frac1{n+1}\right)\\=1+o(1)+1-\frac 1{n+1}+\frac{\sum\limits_{k=2}^{n+1}\frac 1j}{n+1}\\=2+o(1)+\frac{O(\log n)}{n+1}$$
- 从而 $$S_n\to2$$