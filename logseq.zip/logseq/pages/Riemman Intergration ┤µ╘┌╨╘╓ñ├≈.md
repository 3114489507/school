## 概述
- > 若 $$f(x)$$ 在 $$[a,b]$$ 上连续，则 $$f(x)$$ 在 $$[a,b]$$ 上的黎曼积分(*Riemman Intergration*) 被定义为任意满足 $$x_0=a<x_1<x_2<\dots<x_n=b$$ 且 $$\lim\limits_{n\to\infty}\Delta x_i=0$$ 条件的划分的极限
  $$\int_a^bf(x)dx=\lim_{n\to\infty}F_n=\lim_{n\to\infty}\sum_{i=1}^nf(\xi_i)\Delta x_i$$
- 不妨记划分 $$x_0,x_1,x_2,\dots x_n$$ 为 $$S_n$$。
- 在不知道具体的 $$f(x)$$ 情况下，直接证明这个级数收敛于某个常数 $$L$$ 是不切实际的，很难得到与 $$L$$ 有关的渐进。
- 若考虑 *Cauchy Convergence Criterion*，如果能证明任意 $$F_n$$ 与 $$F_n'$$ 误差为 $$o(1)$$，变相可以说明 $$F_n$$ 收敛。
  因为 $$f(x)$$ 在闭区间上连续，可得 $$f(x)$$ 在闭区间上一致连续，即对于任意误差 $$\epsilon$$ 创业板在 $$\delta=\delta(\epsilon)$$ 均有对于任意 $$|\xi-\eta|<\delta,|f(\xi)-f(\eta)|<\epsilon$$。
- 直观上来说，如若 $$\max\limits_{\Delta x_i\in S_n} \Delta x_i<\delta$$,那么每一个子划分与实际面积的误差是 $$-\epsilon\Delta x_i<s_i-f(\xi_i)\Delta x_i<\epsilon\Delta x_i$$。 累加可得到总误差 $$\Epsilon=|S-\sum|<(b-a)\epsilon=o(1)$$。进而任意两个满足 $$\max \Delta x_i<\delta$$ 的划分 $$S_n,S_n'$$ 的误差不超过 $$2(b-a)\epsilon$$。
- ## 分析学处理
- 以上是基于直觉的思考，有必要将其进行严谨表述。