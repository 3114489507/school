- > 1. 求极限
  $$\lim_{x\to\infty}x^4\left(\arctan\left(\frac{2x^2+5}{x^2+1}\right)-\arctan\left(\frac{2x^2+7}{x^2+2}\right)\right)$$
- 我们先搞清楚我们的精度要求，不难有极限的最外层要求精度为 $$o(1)$$，因此对于内层的精度要求为 $$o\left(\frac1{x^4}\right)$$
- 此时注意到两个 $$\arctan$$ 内部的行为是十分相似的，并且 $$x^2$$ 的系数均为 $$1$$ 比 $$2$$，不妨由此为切入点。
- 令内层为 $$S_x$$，不难写出
  $$S_x=\arctan\left(2+\frac3{x^2+1}\right)-\arctan\left(2+\frac3{x^2+2}\right)$$
- 两个 $$\arctan$$ 均是 $$\arctan\left(2+\text{某个无穷小}\right)$$，考虑对 $$\arctan$$ 做 $$x=2$$ 出的 Taylor，我们有
- $$\arctan(2+x)=\arctan2+\frac x5-\frac{2x^2}{25}+o(x^2)$$
- 我们需要多少精度呢？浅浅尝试一下，不难发现
  $$\frac 3{x^2+1}-\frac3{x^2+2}=\frac3{x^4\left(1+\frac 1{x^2}\right)\left(1+\frac2{x^2}\right)}=\frac 3{x^4}(1+o(1))=\frac 3{x^4}+o\left(\frac1{x^4}\right)$$
- 此时已经达到我们的精度要求了，因此只用一次项的精度就足以解决本问题。
- 从而
  $$x^4S_x=\frac35(1+o(1))\to\frac35$$
- > 2. 求极限
  $$\lim_{n\to\infty}\sum_{k=n^2}^{(n+1)^2}\frac1{\sqrt k}$$
- ## 方法一：瞪眼
- 瞪眼的话其实也可以，直接就有
  $$2=\sum_{k=n^2}^{(n+1)^2}\frac1{n+1}<S_n<\sum_{k=n^2}^{(n+1)^2}\frac 1n=\frac{2n+2}n$$
- 显然 $$S_n\to2$$。
- ## 方法二：Taylor
- $$S_n=\sum_{k=0}^{2n+1}\frac1{\sqrt{n^2+k}}\\=\sum_{k=0}^{2n+1}\frac1n(1+o(1))\\=\frac{2n+1}{n}(1+o(1))$$
- 进而
  $$S_n\to2$$
- > 3. 求极限
  $$\lim_{n\to\infty}nsin(2\pi en!)$$
- 相当于对 $$sin(2\pi en!)$$ 做精度为 $$o\left(\frac1n\right)$$ 的估计。
- 注意到 $$e$$ 和 $$n!$$ 关系堪比父子。不妨直接把 $$e$$ 打开，我们有
  $$2\pi en!=2\pi\sum_{k=0}^\infty\frac{n!}{k!}\\=2\pi\left(\sum_{k=0}^n\frac{n!}{k!}+\sum_{k=n+1}^\infty\frac{n!}{k!}\right)\\\equiv2\pi\sum_{k=n+1}^\infty\frac{n!}{k!}\pmod{2\pi}$$
- 瞪眼可得后面这个是个无穷小，
- 考虑对后面这个 $$\sum$$ 做估计，我们有
  $$\sum_{k=n+1}^$$