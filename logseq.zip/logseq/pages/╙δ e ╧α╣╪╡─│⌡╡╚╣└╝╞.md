- >1. 证明  $$a_n=\left(1+\frac{1}{n}\right)^n,b_n=\left(1+\frac{1}{n}\right)^{n+1}$$ 分别单调递增，单调递减。
- 因为 \(a_n\) 是幂形式表达，故考虑研究相邻项比值，从而有
  \[\frac{a_{n+1}}{a_n}=\frac{(n+2)^{n+1}n^n}{(n+1)^{2n+1}}\left(\frac{n\left(n+2\right)}{\left(n+1\right)^2}\right)^n\frac{n+2}{n+1}=\left(1-\frac{1}{\left(n+1\right)^2}\right)^n\frac{n+2}{n+1}\]
  应用伯努利不等式（Bernoulli inequality） \(\left(1+\alpha\right)^n\ge1+n\alpha,\forall \alpha>-1\)，显然有
  \(-\frac{1}{\left(n+1\right)^2}>-1\)，从而
  \[\frac{a_{n+1}}{a_n}\ge\left(1+\frac{n}{\left(n+1\right)^2}\right)\frac{n+2}{n+1}=\frac{n^3+3n^2+3n+2}{n^3+3n^2+3n+1}>1\]
  同理可得\(\frac{b_{n+1}}{b_n}<1\)，又因为 \(a_n<b_n\)，\(a_m\) 单调递增，\(b_m\) 单调递减，\(\lim_{n\to\infty}\frac{b_n}{a_n}=1\)，因此存在极限 \(e=\lim_{n\to\infty}a_n=\lim_{n\to\infty}b_n\)。
- >2. \[\left(\frac{n}{e}\right)^n<n!<e\left(n+1\right)\left(\frac{n}{e}\right)^n\]
  且对于 \(n>6\)，我们实际上有：\[n!<n\left(\frac{n}{e}\right)^n\]
-
- 对于 \(\left(\frac{n}{e}\right)^n<n!<e\left(n+1\right)\left(\frac{n}{e}\right)^n\)，借鉴刚才的比值方法研究，不妨设 \(x_n=\left(\frac{n}{e}\right)^n\)，于是\[\frac{x_{n+1}}{x_n}=\frac{(n+1)^{n+1}}{n^ne}<\frac{(n+1)^{n+1}}{n^n\left(\frac{n+1}{n}\right)^n}=n+1\]从而\[x_n=x_1\prod_{k=1}^{n-1}\frac{x_{k+1}}{x_k}<\frac{1}{e}n!<n!\]所以实际上这个下界可以是 \(\frac{n^n}{e^{n-1}}\)，不过对于 \(n=1\)，下界取等。
- 同理可有\[\frac{x_{n+1}}{x_n}>\frac{(n+1)^{n+1}}{n^n\left(\frac{n+1}{n}\right)^{n+1}}=n\]从而\[e(n+1)\left(\frac{n}{e}\right)^n=e(n+1)x_n=e(n+1)x_1\prod_{k=1}^{n-1}\frac{x_{k+1}}{x_k}>(n+1)(n-1)!>n!\]进而一个更好的上界可以是 \(en\left(\frac{n}{e}\right)^n\)。
- ### 以下是一个愚蠢的伪证
- 设 \(y_n=e(n+1)\left(\frac{n}{e}\right)^n\)我们有\[\frac{y_{n+1}}{y_n}=\frac{(n+2)(n+1)^{n+1}}{(n+1)n^ne}>\frac{(n+2)(n+1)^{n+1}}{(n+1)n^n\left(\frac{n+1}{n}\right)^{n+1}}>\frac{n(n+2)}{n+1}>n\]从而\[y_n=y_1\prod_{k=1}^{n-1}\frac{y_{k+1}}{y_k}>n!\]