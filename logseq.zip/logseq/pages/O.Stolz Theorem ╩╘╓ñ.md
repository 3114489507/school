- > 假设 $$\frac{a_n}{b_n}\to L$$，并保证 $$b_n\to\infty$$ 且 $$b_n$$ 单调递增，则有
  $$\frac{\Delta a_n}{\Delta b_n}\to L$$
- 我们必须先想明白，我们究竟是要证明
  $$\frac{\Delta a_n}{\Delta b_n}-\frac{a_n}{b_n}\to0$$
- 还是证明
  $$\frac{\frac{\Delta a_n}{\Delta b_n}}{\frac{a_n}{b_n}}\to1$$
- 这两种形式有什么区别？显然，第一个表明
  $$\frac{\Delta a_n}{\Delta b_n}=\frac{a_n}{b_n}+o(1)$$
- 而第二个表明
  $$\frac{\Delta a_n}{\Delta b_n}=\frac{a_n}{b_n}(1+o(1))$$
- 很显然第一个是强于第二个的。但是这两个都能推导出我们想要的结论，两个都可以吗？贪心角度来说，肯定使用第二个。于是我们问题转变成了
- > 假设 $$\frac{a_n}{b_n}$$ 收敛，保证 $$b_n\to\infty$$，求证
  $$\frac{\frac{\Delta a_n}{\Delta b_n}}{\frac{a_n}{b_n}}\to1$$
- 这等价于证明
  $$\frac{\frac{a_{n+1}}{a_n}-1}{\frac{b_{n+1}}{b_n}-1}\to1$$
- 不妨设 $$p_n=\frac{a_{n+1}}{a_n},q_n=\frac{b_{n+1}}{b_n}$$，等价于证明
  $$\frac{p_n-1}{q_n-1}\to1$$
- 然后我们的还有一个极限条件还么有用上，容易注意到
  $$\frac{p_n}{q_n}=\frac{a_{n+1}}{b_{n+1}}\frac{b_n}{a_n}\to1$$
- 如何应用这个条件呢？不妨将其打开，我们有
  $$p_n=q_n(1+\epsilon)$$
- 不难有
  $$p_n-1=(q_n-1)(1+\epsilon)+\epsilon$$
- 从而
  $$\frac{p_n-1}{q_n-1}=1+\epsilon\frac{q_n}{q_n-1}$$
- 此时我们发现，这玩意竟然不收敛，这表明 Stolz Theorem 的逆定理是不成立的。我搞反了条件与结论。