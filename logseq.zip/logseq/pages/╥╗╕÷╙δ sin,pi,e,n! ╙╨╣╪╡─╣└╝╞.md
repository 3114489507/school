- >	求极限
  $$\lim_{n\to\infty}nsin(2\pi en!)$$
- 根据 #逐项估计 原则，此题相当于对 $$sin(2\pi en!)$$ 做精度为 $$o\left(\frac1n\right)$$ 的估计。
- 注意到 $$e$$ 和 $$n!$$ 关系堪比父子。不妨直接把 $$e$$ 打开，我们有
  $$2\pi en!=2\pi\sum_{k=0}^\infty\frac{n!}{k!}\\=2\pi\left(\sum_{k=0}^n\frac{n!}{k!}+\sum_{k=n+1}^\infty\frac{n!}{k!}\right)\\\equiv2\pi\sum_{k=n+1}^\infty\frac{n!}{k!}\pmod{2\pi}$$
- 瞪眼可得这是个无穷小，此时根据 $$\sin x=x-\frac{x^3}{3!}+o(x^3)$$ 对后面这个 $$\sum$$ 做估计，我们有
  $$\sum_{k=n+1}^\infty\frac{n!}{k!}=\frac 1n+o\left(\frac 1n\right)$$
- 从而
  $$\sin(2\pi en!)=\frac{2\pi}n+\left(\frac1n\right)$$
- 进而
  $$S_n\to2\pi$$